<?php
$host = "127.0.0.1";
$user = "root";
$pass = "";
$db = "sas";

mysql_connect($host, $user, $pass);
mysql_select_db($db);
?>
