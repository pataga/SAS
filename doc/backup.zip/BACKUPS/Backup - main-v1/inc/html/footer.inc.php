        <div class="clear"></div>
    </div>
<!-- // #container -->
</div>	
<!-- // #containerHolder -->

<p id="footer">
    SAS - Server Admin System | Klasse: 2BKI2 <br><br> 
    <a href="#">Patrick Farnkopf</a> | <a href="#">Tanja Weiser</a> | <a href="http://mangopix.de">Gabriel Wanzek</a>
    <br><br>
    <!--Aktuelle Datei (Entwicklungshilfe):
    <strong>  
        <?php //echo '<br><br>'. $_SERVER["SCRIPT_NAME"]; ?>
    </strong>-->
    <br>
    <strong><a class="logoutfooter" href="logout.php">LOGOUT</a></strong>
    </p>
</div>
</body>
</html>