<h3> Hier ensteht die Seite "CPU Auslastung"</h3>
<fieldset>
    <p>Pfad zur Datei mit Inhalt: 
        <br><br>
        <?php echo __file__; ?></p>
</fieldset>

