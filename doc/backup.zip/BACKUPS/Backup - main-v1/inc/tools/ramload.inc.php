<h3> Hier ensteht die Seite "RAM Auslastung"</h3>
<fieldset>
    <p>Pfad zur Datei mit Inhalt: 
        <br><br>
        <?php echo __file__; ?></p>
</fieldset>
