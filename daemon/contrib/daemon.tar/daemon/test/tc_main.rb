require 'test/unit'

#CURRENT_DIR = File.split(File.expand_path(__FILE__))[0]

#$LOAD_PATH << File.join(CURRENT_DIR, '../lib')


require 'pp'

require 'daemons'


class TestMain < Test::Unit::TestCase

  def test_argv_parsing
  end
  
  def test_run
    #Daemons.run(File.join(CURRENT_DIR,'testapp.rb'))
  end
  
end


