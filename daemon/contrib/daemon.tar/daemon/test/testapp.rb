
require 'pp'

puts "Application ARGV:"
pp ARGV


loop do
  sleep(5)
end
 
